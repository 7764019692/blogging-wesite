BLOG POST WEBSITE BUILT USING FLASK
Features:-
1. Login/Registration
2. Modern UI
3. All posts
4. Edit Posts
5. Drafts
6. Delete Posts
7. Logout
8. Email Notifications when you register or post a blog
